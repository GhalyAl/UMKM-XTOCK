<?php
class Home extends CI_Controller{
    public function index(){
        // render view
        $this->load->view('home/index');

    }
}
?>