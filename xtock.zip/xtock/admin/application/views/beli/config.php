<?php
$server = "localhost";
$userame  = "root";
$password  = "";
$database  = "dbprodukumkm";

$connect = mysqli_connect($server,$userame,$password,$database) or die ("Gagal");
?>